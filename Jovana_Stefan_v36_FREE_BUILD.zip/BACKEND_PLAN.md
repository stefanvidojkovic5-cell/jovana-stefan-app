# Cloud stage — implementation contract

The Android shell is now prepared. The existing app is bundled unchanged inside the Android assets.

For the shared two-phone version, the remaining external prerequisite is the private cloud project credentials. Once supplied, the app will use:
- two authenticated users: Jovana and Stefan
- shared database records with `createdBy` and timestamps
- realtime listeners for schedule, dates, messages, tasks, list, expenses and trips
- cloud photo storage
- push notification tokens per device
- notification preference per change
- quick-message notifications
- security rules limiting access to the two users

No payment is required for the app code itself; the selected backend must be configured on a free/appropriate tier if available.
