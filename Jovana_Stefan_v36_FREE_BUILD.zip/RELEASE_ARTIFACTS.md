# Release artifacts

Source package:
- Android project
- bundled web UI
- Firebase config
- Firebase rules
- Cloud Functions notification sender
- cloud repositories
- migration/schema files

The project is ready for a real Android build environment. The final APK/AAB
cannot be produced inside this phone-only workflow unless an Android build
environment is available.
