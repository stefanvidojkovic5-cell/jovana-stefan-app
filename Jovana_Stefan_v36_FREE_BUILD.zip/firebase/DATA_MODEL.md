# Firestore model

couples/{coupleId}
  members/{uid}
    name: "Jovana" | "Stefan"
    role: "member"
    createdAt

  schedules/{id}
    ownerUid
    date
    status: "R" | "SD" | "O"
    shift: "1" | "2" | "M" | "C"
    createdAt
    updatedAt

  dates/{id}
  messages/{id}
  tasks/{id}
  listItems/{id}
  photos/{id}
  expenseTargets/{id}
  expenseEntries/{id}
  trips/{id}
    destination
    from
    to
    transport
    stay
    people
    other
    createdBy
    createdAt
    updatedAt

  trips/{tripId}/activities/{activityId}
    name
    date
    time
    note
    createdAt
    updatedAt

  trips/{tripId}/costs/{costId}
    what
    amount
    currency
    createdAt
    updatedAt

  notifications/{id}
    recipientUid
    senderUid
    type
    text
    read
    createdAt
