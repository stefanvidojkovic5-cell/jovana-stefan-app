// Cloud Function implementation contract.
// Trigger on couples/{coupleId}/notifications/{notificationId}.
// Send the notification to recipientUid's registered FCM tokens.
// Security validation must happen server-side; clients cannot choose arbitrary recipients.
export const notificationContract = {
  trigger: "couples/{coupleId}/notifications/{notificationId}",
  payload: ["title","body","type","coupleId","notificationId"],
  recipientField: "recipientUid"
};
