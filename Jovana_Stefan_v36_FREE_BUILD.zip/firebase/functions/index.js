const {onDocumentCreated} = require("firebase-functions/v2/firestore");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore} = require("firebase-admin/firestore");
const {getMessaging} = require("firebase-admin/messaging");
initializeApp();
const db=getFirestore();

exports.sendCoupleNotification=onDocumentCreated(
  "couples/{coupleId}/notifications/{notificationId}",
  async event=>{
    const n=event.data?.data();
    if(!n?.recipientUid || !n?.text) return;
    const member=await db.doc(
      `couples/${event.params.coupleId}/members/${n.recipientUid}`
    ).get();
    if(!member.exists) return;
    const devices=await db.collection(
      `couples/${event.params.coupleId}/members/${n.recipientUid}/devices`
    ).get();
    const tokens=devices.docs.map(d=>d.data().token).filter(Boolean);
    if(!tokens.length) return;
    await getMessaging().sendEachForMulticast({
      tokens,
      notification:{title:"Jovana & Stefan",body:String(n.text).slice(0,180)},
      data:{type:String(n.type||"change"),coupleId:event.params.coupleId,
            notificationId:event.params.notificationId}
    });
  }
);
