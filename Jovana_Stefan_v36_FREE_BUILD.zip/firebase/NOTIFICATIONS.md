# Notification contract

A notification is created only when the user explicitly requests notification
for a change. Quick messages can create a notification immediately.

Types:
- schedule_changed
- date_changed
- message_received
- task_changed
- list_changed
- expense_changed
- trip_changed
- photo_added
- quick_message

The production Cloud Function should:
1. validate sender/recipient are members of the same couple;
2. read the recipient's FCM device token(s);
3. send an FCM notification;
4. keep an in-app notification document;
5. never expose a user's password or authentication token.
