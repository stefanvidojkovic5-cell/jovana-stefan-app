// Generated from the user-provided google-services.json.
// Values are safe client configuration; no password is stored here.
export const firebaseConfig = {
  apiKey: "AIzaSyCC8s9vrjyxM2mUpxupmedmvycU447O4xo",
  authDomain: "jovana-stefan.firebaseapp.com",
  projectId: "jovana-stefan",
  storageBucket: "jovana-stefan.firebasestorage.app",
  messagingSenderId: "809609923739",
  appId: "1:809609923739:android:3495c1b2d2536fe8e2ca3e"
};
