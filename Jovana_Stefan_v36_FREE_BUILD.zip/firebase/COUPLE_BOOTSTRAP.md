# Couple bootstrap

After Auth creates the two accounts, a couple document should be created:
couples/{coupleId}

members/{jovanaUid}
  name: Jovana
  role: member

members/{stefanUid}
  name: Stefan
  role: member

The coupleId is generated deterministically from the two UIDs:
sorted([uidA, uidB]).join("_")

No account password is stored in Firestore.
