# Jovana & Stefan — realna verzija, priprema v16

Ovo je nadogradnja postojeće aplikacije. Ništa iz prethodne verzije nije namerno uklonjeno.

## Cilj konačne verzije

1. Jovana i Stefan imaju odvojene naloge.
2. Podaci se čuvaju u privatnom cloud-u i vide se na oba telefona.
3. Promene se sinhronizuju između uređaja.
4. Obaveštenja se šalju drugoj osobi samo kada je izabrano obaveštavanje, dok brze poruke mogu imati podrazumevano obaveštenje.
5. Slike se čuvaju u cloud storage-u.
6. Sve postojeće sekcije ostaju:
   - raspored
   - naši datumi
   - poruke
   - zajedničke obaveze
   - naša lista
   - naše slike
   - zajednički troškovi
   - planirana putovanja
7. Putovanja imaju više aktivnosti, a svaka aktivnost može imati datum, vreme i napomenu.
8. Putovanja imaju više pojedinačnih troškova.

## Važna napomena

v16 je priprema arhitekture. Aplikacija i dalje radi lokalno kao ranije. Cloud deo ne treba uključivati dok ne postoji konkretan cloud projekat i njegovi ključevi.

## Kada je potreban Stefan

Tek kada dođemo do povezivanja pravog naloga/cloud projekta i eventualne instalacije na telefonu, biće potrebna tvoja kratka potvrda/prijava. Ne treba ti računar za samo korišćenje aplikacije.

Do tada mogu da nastavim da sređujem kod i funkcionalnosti bez tvoje intervencije.
