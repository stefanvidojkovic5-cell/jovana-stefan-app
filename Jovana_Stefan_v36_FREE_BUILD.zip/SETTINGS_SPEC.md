# Settings / safety

Planned production settings:
- Jovana / Stefan profile
- Cloud connection status
- Notification preference
- Export backup
- Import backup
- Sign out

Backup is non-destructive: importing should replace state only after explicit
confirmation and after an automatic local snapshot is created.
