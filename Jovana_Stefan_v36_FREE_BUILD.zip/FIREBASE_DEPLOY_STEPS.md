# Firebase deployment package

The project now contains the client repository layer, photo upload layer and
notification document creation layer.

The only external action still required is deploying to a real Firebase project
owned by the user. No private credentials are stored here.

Required project services:
- Authentication: Email/Password
- Firestore
- Storage
- Cloud Messaging
- Cloud Functions (for actual push delivery)

Security rules are already included in the package.
