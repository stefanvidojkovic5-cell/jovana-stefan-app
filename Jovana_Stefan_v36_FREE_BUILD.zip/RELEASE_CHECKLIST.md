# Release checklist

Code prepared:
[x] Android wrapper
[x] Firebase Android config
[x] Auth bridge
[x] Firestore repository
[x] Storage photo upload
[x] FCM client/server contract
[x] Device token repository
[x] Security rule skeleton
[x] Notification preference helper
[x] Non-destructive migration
[x] Couple membership model

External project actions remaining:
[ ] Enable Firebase services in the user-owned console
[ ] Deploy rules/functions
[ ] Create Jovana + Stefan accounts
[ ] Register/test both Android devices
[ ] Build and sign release APK
