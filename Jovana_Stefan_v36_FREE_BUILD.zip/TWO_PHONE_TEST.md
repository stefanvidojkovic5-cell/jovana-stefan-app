# Two-phone acceptance test

Phone A (Jovana):
- sign in
- add one schedule entry
- check notification option
- add one message
- add one trip activity
- upload one photo

Phone B (Stefan):
- sign in with Stefan account
- confirm all cloud changes appear
- confirm selected notifications arrive
- edit one shared item

Then repeat in reverse.

Offline:
- disable internet
- create a local change
- restore internet
- verify migration/sync behavior without data loss.
