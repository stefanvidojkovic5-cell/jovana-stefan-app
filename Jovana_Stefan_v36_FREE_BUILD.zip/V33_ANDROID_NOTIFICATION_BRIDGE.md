# v33 — Android notification bridge

The Android wrapper now exposes `AndroidCloudBridge` to the bundled app.

Implemented:
- JS -> Android notification call
- Android notification channel
- Android 13+ notification permission request remains enabled
- session values can be retained locally through SharedPreferences
- existing WebView/local app behavior is preserved

Important:
- These are local Android notifications triggered by the app.
- Cross-phone push still requires Firebase Cloud Messaging + deployed backend.
- No existing app feature was removed.
