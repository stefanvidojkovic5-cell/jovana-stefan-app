# Android build status

Firebase configuration is now attached to the Android project.

Project:
- Firebase project: jovana-stefan
- Android package: com.jovanastefan.app
- Firebase Android app ID is recorded in FIREBASE_CONNECTED.json

Next build actions:
1. Sync Gradle.
2. Build a debug APK for testing.
3. Configure Firebase Auth, Firestore, Storage and FCM in the project.
4. Deploy the included rules/functions.
5. Create the two couple member accounts and verify notifications.
6. Produce a signed release APK/AAB for installation.

The uploaded Firebase config contains project identifiers/API key but no password.
