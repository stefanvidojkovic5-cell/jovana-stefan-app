# Final architecture

Android app
  -> Firebase Authentication
  -> Firestore (shared couple data + realtime listeners)
  -> Firebase Storage (shared photos)
  -> Firebase Cloud Messaging (push notifications)

Offline behavior:
  -> existing localStorage cache remains available
  -> cloud sync activates after authentication

Privacy:
  -> only authenticated couple members can read/write couple data
  -> passwords remain with Firebase Authentication
  -> notification recipient is validated server-side
  -> photo access is protected by Storage rules
