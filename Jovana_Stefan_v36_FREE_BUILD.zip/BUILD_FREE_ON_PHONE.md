# Besplatno pravljenje APK-a preko telefona

Ne treba Android Studio i ne treba plaćeni servis.

Najjednostavnije:
1. Na GitHub-u napravi NOVI JAVNI repository, npr. `jovana-stefan-app`.
2. Uploaduj kompletan sadržaj ovog ZIP-a u repository (uključujući `android/` i `.github/`).
3. Otvori **Actions**.
4. Pokreni workflow **Build Android APK** preko **Run workflow**.
5. Kada se završi, otvori poslednji workflow run.
6. U **Artifacts** preuzmi `Jovana-Stefan-debug-apk`.
7. Raspakuj artifact ZIP i instaliraj `app-debug.apk` na telefon.
8. Na drugom telefonu instalira se isti APK; prijava određuje Jovana/Stefan nalog.

VAŽNO:
- Repository mora biti PUBLIC ako želiš GitHub Actions bez plaćanja.
- Nemoj objavljivati lozinke ili privatne ključeve.
- `google-services.json` je Firebase Android client konfiguracija; ipak je najbolje da repository bude samo za ovu aplikaciju.
- Ovo pravi debug APK besplatno. Za ličnu upotrebu nije potreban Play Store.
- Ako GitHub prikaže grešku u build-u, pošalji screenshot/log i popravićemo konkretan problem.
