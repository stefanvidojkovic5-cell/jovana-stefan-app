# v34 — notification smoke test

On an Android build:
1. Open the app.
2. Grant notification permission if Android asks.
3. Tap “🔔 Test obaveštenja”.
4. Confirm the Android notification appears.

This validates the WebView → Android local notification bridge.
It does not yet validate cross-device FCM delivery.
