# v32 — final integration layer

Added:
- non-destructive JavaScript/native bridge
- AndroidCloudBridge hook for session + notifications
- browser/local behavior remains intact when the bridge is unavailable
- final integration notes

Still external/runtime:
- enable Firebase Authentication (Email/Password)
- create Firestore + Storage
- deploy Cloud Functions
- create the two accounts and couple membership
- perform Android release build/sign/install

No existing feature was removed.
