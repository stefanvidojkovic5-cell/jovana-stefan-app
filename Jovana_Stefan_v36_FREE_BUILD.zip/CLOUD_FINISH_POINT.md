# Cloud finish point

At this stage the code side of:
- Firebase Auth bridge
- Firestore shared repository
- Storage photo upload
- FCM notification repository
- server-side FCM sender
- device token registration
- Firestore/Storage security rules
- non-destructive migration
is prepared.

The remaining dependency is the actual Firebase project owned by the user.
Without that project there is no legitimate way to create the real
`google-services.json`, production database, or push credentials.

After that one external setup, the final Android build/signing/install step can
be completed.
