# Firebase final checklist

Project configuration has been attached to the Android project.

In the Firebase Console, the following must be enabled before live use:
1. Authentication -> Sign-in method -> Email/Password
2. Firestore Database -> Create database
3. Storage -> Get started
4. Cloud Messaging -> Android app registered
5. Functions -> deploy notification function

Then:
- create Jovana account
- create Stefan account
- create one couple membership linking both UIDs
- test schedule sync
- test message notification
- test task reminder/notification
- test trip/expense/photo sync

Do not put passwords into Firestore or into the project files.
