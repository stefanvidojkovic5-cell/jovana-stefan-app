# Completion matrix

Code-side prepared:
- Existing app/features preserved
- Travel activities subgroup
- Travel cost subgroup
- Shared data schema
- Firestore repository
- Realtime sync coordinator
- Auth bridge
- Storage upload
- FCM notification repository
- FCM server sender
- Device token registration
- Security rules
- Migration helpers
- Backup/export/import helpers
- Android wrapper and notification permission

Requires the real project/runtime:
- Firebase services enabled in the console
- deploy rules/functions
- create two authenticated accounts
- connect both devices
- execute Android build/signing
- install and test on the two physical phones
