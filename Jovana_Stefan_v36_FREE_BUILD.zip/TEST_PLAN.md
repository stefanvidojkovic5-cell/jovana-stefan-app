# Test plan

## Schedule
- Jovana and Stefan can have separate entries.
- R/SD/O render correctly.
- R requires shift 1/2/M/C.
- Existing compact J/S labels remain.
- Edit and delete work.

## Trips
- Multiple activities per trip.
- Each activity supports date/time/note.
- Multiple costs per trip.
- Edit-all modal preserves all activity/cost rows.

## Expenses
- Each target has its own donut.
- Adding money increases only the selected target.
- No target means no target graph.

## Notifications
- Change notification only exists when the user checks notify.
- Quick messages create a notification.
- Recipient cannot be arbitrary outside the couple.

## Offline
- Local state remains available without cloud.
- Migration does not delete local data.
