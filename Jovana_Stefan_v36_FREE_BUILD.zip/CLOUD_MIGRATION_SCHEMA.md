# Cloud migration schema

Existing local state is mapped non-destructively:
- schedules -> schedules
- dates -> dates
- messages -> messages
- tasks -> tasks
- list -> listItems
- photos -> photos
- expense targets -> expenseTargets
- expense entries -> expenseEntries
- trips -> trips, with subcollections activities and costs
- notifications -> notifications

The migration never clears localStorage. A successful upload is recorded only
after the remote write succeeds.
