# Regression checklist

Existing behavior that must remain:
- Schedule J/S labels and R·1/R·2/R·M/R·C compact shift display.
- Bulk schedule entry and individual edit/delete.
- Dates edit/delete.
- Messages, quick messages and notification checkbox.
- Tasks with green/yellow/red status logic, edit/delete.
- Our list types, optional planned dates and green/yellow/red status.
- Shared expenses: target-only donut per target, add money, currency, edit/delete.
- Trips: dates, transport, stay, people, multiple activities and multiple costs,
  edit-all modal, delete.
- Photos section.
- Offline localStorage fallback.
