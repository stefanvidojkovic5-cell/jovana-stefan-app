package com.jovanastefan.app;

import android.app.Activity;
import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Notification;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ActivityCompat;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.JavascriptInterface;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }
        webView = new WebView(this);
        setContentView(webView);
        createJsNotificationChannel();
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidCloudBridge(this), "AndroidCloudBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void createJsNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(
                "jovana_stefan", "Jovana & Stefan", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Obaveštenja aplikacije Jovana & Stefan");
            nm.createNotificationChannel(ch);
        }
    }

    private void showLocalNotification(String title, String body) {
        String channelId = "jovana_stefan";
        NotificationManager nm = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                channelId, "Jovana & Stefan", NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(ch);
        }
        Notification n = new NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title == null ? "Jovana & Stefan" : title)
            .setContentText(body == null ? "" : body)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build();
        nm.notify((int)(System.currentTimeMillis() & 0x7fffffff), n);
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public static class AndroidCloudBridge {
        private final MainActivity activity;
        AndroidCloudBridge(MainActivity activity) { this.activity = activity; }

        @JavascriptInterface public void ready() {}

        @JavascriptInterface public void setSession(String uid, String email, String name) {
            SharedPreferences p = activity.getSharedPreferences("js_session", Context.MODE_PRIVATE);
            p.edit().putString("uid", uid).putString("email", email).putString("name", name).apply();
        }

        @JavascriptInterface public void notify(String title, String body) {
            activity.runOnUiThread(() -> activity.showLocalNotification(title, body));
        }
    }
}
