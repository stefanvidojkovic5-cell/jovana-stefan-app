package com.jovanastefan.app;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import android.util.Log;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    @Override public void onMessageReceived(RemoteMessage message) {
        Log.d("JS_PUSH", "Primljeno obaveštenje za Jovana & Stefan");
        // Notification UI is wired after the private Firebase project is connected.
    }
    @Override public void onNewToken(String token) {
        Log.d("JS_PUSH", "FCM token refreshed");
    }
}
