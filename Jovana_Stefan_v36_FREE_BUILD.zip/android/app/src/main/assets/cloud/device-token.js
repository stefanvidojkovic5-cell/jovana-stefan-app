export async function registerDeviceToken(db,coupleId,uid,token){
  const {doc,setDoc,serverTimestamp}=await import(
    "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js");
  const deviceId=(crypto.randomUUID?crypto.randomUUID():String(Date.now()));
  await setDoc(doc(db,"couples",coupleId,"members",uid,"devices",deviceId),{
    token,platform:"android",createdAt:serverTimestamp(),updatedAt:serverTimestamp()
  },{merge:true});
}
