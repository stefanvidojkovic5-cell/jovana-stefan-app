export class SyncCoordinator {
  constructor({db,coupleId,uid,onRemoteState}){
    this.db=db;this.coupleId=coupleId;this.uid=uid;this.onRemoteState=onRemoteState;
    this.unsubscribers=[];
  }
  async start(){
    const {doc,onSnapshot}=await import(
      "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js");
    const ref=doc(this.db,"couples",this.coupleId);
    const unsub=onSnapshot(ref,snap=>{
      if(snap.exists() && snap.data().state && snap.data().updatedBy!==this.uid){
        this.onRemoteState(snap.data().state);
      }
    });
    this.unsubscribers.push(unsub);
  }
  async pushState(state){
    const {doc,setDoc,serverTimestamp}=await import(
      "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js");
    await setDoc(doc(this.db,"couples",this.coupleId),{
      state,updatedBy:this.uid,updatedAt:serverTimestamp()
    },{merge:true});
  }
  stop(){this.unsubscribers.forEach(x=>x());this.unsubscribers=[];}
}
