/**
 * Shared application data layer.
 * Collections are intentionally explicit so the local state can migrate
 * without losing any existing feature.
 */
export const COLLECTIONS = Object.freeze([
  "schedules","dates","messages","tasks","listItems","photos",
  "expenseTargets","expenseEntries","trips","notifications"
]);

export function cleanSchedule(entry){
  return {
    date:entry.date||"",
    status:entry.status||"SD",
    shift:entry.status==="R"?(entry.shift||"1"):"",
    ownerUid:entry.ownerUid||""
  };
}

export function shouldNotify(form){
  return !!form?.notifyOther;
}

export function quickMessage(text,senderUid,recipientUid){
  return {
    type:"quick_message", text, senderUid, recipientUid,
    read:false, createdAt:Date.now()
  };
}
