export class CoupleSession {
  constructor(auth){this.auth=auth;this.user=null;this.stopper=null;}
  watch(callback){
    if(this.stopper)this.stopper();
    this.stopper=this.auth.onAuthStateChanged(this.auth,u=>{
      this.user=u||null; callback(this.user);
    });
    return this.stopper;
  }
  get uid(){return this.user?.uid||null;}
  isSignedIn(){return !!this.user;}
}
