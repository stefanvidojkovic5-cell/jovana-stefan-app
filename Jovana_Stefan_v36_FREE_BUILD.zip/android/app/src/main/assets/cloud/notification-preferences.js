export const NotificationTypes = Object.freeze({
  schedule:"schedule_changed", date:"date_changed", message:"message_received",
  task:"task_changed", list:"list_changed", expense:"expense_changed",
  trip:"trip_changed", photo:"photo_added", quick:"quick_message"
});
export function notificationForChange({notifyOther,recipientUid,senderUid,type,text}){
  if(!notifyOther) return null;
  return {recipientUid,senderUid,type,text,read:false,createdAt:Date.now()};
}
