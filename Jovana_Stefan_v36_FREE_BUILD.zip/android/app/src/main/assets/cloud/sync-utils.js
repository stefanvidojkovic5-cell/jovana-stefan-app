/**
 * Offline-first merge policy:
 * - newest updatedAt wins for whole-state fallback;
 * - normalized production collections should use per-document updatedAt.
 */
export function chooseRemote(local, remote, localUpdatedAt, remoteUpdatedAt){
  if(!remote) return local;
  if(!local) return remote;
  return Number(remoteUpdatedAt||0)>=Number(localUpdatedAt||0) ? remote : local;
}
export function makeCoupleId(uidA, uidB){
  return [uidA,uidB].sort().join("_");
}
