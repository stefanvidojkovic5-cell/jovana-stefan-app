export async function watchCollection(db,coupleId,name,onChange){
  const {collection,onSnapshot}=await import(
    "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js");
  return onSnapshot(
    collection(db,"couples",coupleId,name),
    snap=>onChange(snap.docChanges().map(c=>({
      type:c.type,id:c.doc.id,data:c.doc.data()
    })))
  );
}
