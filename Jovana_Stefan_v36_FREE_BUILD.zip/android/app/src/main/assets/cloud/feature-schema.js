export const FEATURE_SCHEMA = {
  schedules:{collection:"schedules", owner:"ownerUid"},
  dates:{collection:"dates", owner:"createdBy"},
  messages:{collection:"messages", owner:"senderUid"},
  tasks:{collection:"tasks", owner:"createdBy"},
  list:{collection:"listItems", owner:"createdBy"},
  photos:{collection:"photos", owner:"createdBy"},
  expenseTargets:{collection:"expenseTargets", owner:"createdBy"},
  expenseEntries:{collection:"expenseEntries", owner:"createdBy"},
  trips:{collection:"trips", owner:"createdBy"},
  notifications:{collection:"notifications", owner:"senderUid"}
};

export function documentEnvelope(data,uid){
  return {...data,createdBy:data.createdBy||uid,updatedBy:uid,updatedAt:Date.now()};
}
