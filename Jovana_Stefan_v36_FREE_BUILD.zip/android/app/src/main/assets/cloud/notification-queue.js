export function buildNotification({
  coupleId,recipientUid,senderUid,type,text,notifyOther=true
}){
  if(!notifyOther || !recipientUid || recipientUid===senderUid) return null;
  return {
    coupleId,recipientUid,senderUid,type,text:String(text).slice(0,500),
    read:false,createdAt:Date.now()
  };
}
