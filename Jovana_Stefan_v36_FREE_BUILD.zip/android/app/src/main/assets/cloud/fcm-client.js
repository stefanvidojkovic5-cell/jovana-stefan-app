export async function requestPushToken(messaging,vapidKey){
  if(!messaging || !("Notification" in window)) return null;
  const {getToken}=await import("https://www.gstatic.com/firebasejs/12.4.0/firebase-messaging.js");
  if(Notification.permission==="default") await Notification.requestPermission();
  if(Notification.permission!=="granted") return null;
  try{return await getToken(messaging,{vapidKey});}catch(_){return null;}
}
