export async function uploadCouplePhoto(storage,coupleId,uid,file){
  const {ref,uploadBytes,getDownloadURL}=await import("https://www.gstatic.com/firebasejs/12.4.0/firebase-storage.js");
  const safe=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
  const path=`couples/${coupleId}/photos/${uid}/${Date.now()}_${safe}`;
  const r=ref(storage,path);
  await uploadBytes(r,file,{contentType:file.type||"image/jpeg"});
  return {path,url:await getDownloadURL(r)};
}
