export class ConnectionManager {
  constructor({firebaseConfig,onModeChange,onUserChange}){
    this.firebaseConfig=firebaseConfig;
    this.onModeChange=onModeChange||(()=>{});
    this.onUserChange=onUserChange||(()=>{});
    this.app=null;this.auth=null;this.db=null;this.storage=null;this.messaging=null;
  }
  async connect(){
    if(!this.firebaseConfig?.apiKey || !this.firebaseConfig?.projectId){
      this.onModeChange("local"); return false;
    }
    try{
      const [{initializeApp},{getAuth,onAuthStateChanged},
             {getFirestore},{getStorage},{getMessaging}]=await Promise.all([
        import("https://www.gstatic.com/firebasejs/12.4.0/firebase-app.js"),
        import("https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js"),
        import("https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js"),
        import("https://www.gstatic.com/firebasejs/12.4.0/firebase-storage.js"),
        import("https://www.gstatic.com/firebasejs/12.4.0/firebase-messaging.js")
      ]);
      this.app=initializeApp(this.firebaseConfig);
      this.auth=getAuth(this.app);
      this.db=getFirestore(this.app);
      this.storage=getStorage(this.app);
      try{this.messaging=getMessaging(this.app)}catch(_){}
      onAuthStateChanged(this.auth,u=>this.onUserChange(u||null));
      this.onModeChange("cloud");
      return true;
    }catch(e){
      console.warn("Cloud connection failed; local mode remains active.",e);
      this.onModeChange("local"); return false;
    }
  }
}
