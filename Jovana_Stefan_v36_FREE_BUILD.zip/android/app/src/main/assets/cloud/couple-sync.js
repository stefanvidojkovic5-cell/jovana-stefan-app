/**
 * Jovana & Stefan — Firestore sync layer
 * Keeps localStorage as an offline cache and synchronizes a couple document.
 */
export class CoupleSync {
  constructor({db, auth, coupleId, onRemote}) {
    this.db=db; this.auth=auth; this.coupleId=coupleId; this.onRemote=onRemote;
    this.unsubscribe=null;
  }
  async start() {
    const {doc, onSnapshot}=await import("https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js");
    const ref=doc(this.db,"couples",this.coupleId);
    this.unsubscribe=onSnapshot(ref,snap=>{
      if(snap.exists() && snap.data().state) this.onRemote(snap.data().state);
    });
  }
  async push(state) {
    const {doc,setDoc,serverTimestamp}=await import("https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js");
    if(!this.auth?.currentUser) return;
    await setDoc(doc(this.db,"couples",this.coupleId),{
      state,
      updatedBy:this.auth.currentUser.uid,
      updatedAt:serverTimestamp()
    },{merge:true});
  }
  stop(){if(this.unsubscribe)this.unsubscribe();}
}
