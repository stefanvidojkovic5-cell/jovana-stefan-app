export async function createChangeNotification(db,coupleId,{recipientUid,senderUid,type,text}){
  const {addDoc,collection,serverTimestamp}=await import("https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js");
  return addDoc(collection(db,"couples",coupleId,"notifications"),{
    recipientUid,senderUid,type,text,read:false,createdAt:serverTimestamp()
  });
}
