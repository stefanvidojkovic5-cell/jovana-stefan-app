/**
 * Firestore repository for the shared couple.
 * Uses one document per item and preserves updatedAt/updatedBy metadata.
 */
export class FirestoreRepository {
  constructor(db,coupleId,uid){this.db=db;this.coupleId=coupleId;this.uid=uid;}
  async set(collection,id,data){
    const {doc,setDoc,serverTimestamp}=await import("https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js");
    return setDoc(doc(this.db,"couples",this.coupleId,collection,id),
      {...data,updatedBy:this.uid,updatedAt:serverTimestamp()},{merge:true});
  }
  async remove(collection,id){
    const {doc,deleteDoc}=await import("https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js");
    return deleteDoc(doc(this.db,"couples",this.coupleId,collection,id));
  }
  watch(collection,callback){
    return import("https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js").then(({collection:col,onSnapshot})=>{
      return onSnapshot(col(this.db,"couples",this.coupleId,collection),s=>{
        callback(s.docs.map(d=>({id:d.id,...d.data()})));
      });
    });
  }
}
