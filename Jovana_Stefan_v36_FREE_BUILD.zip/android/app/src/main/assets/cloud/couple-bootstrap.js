export async function ensureMember(db,coupleId,uid,name){
  const {doc,setDoc,serverTimestamp}=await import(
    "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js");
  await setDoc(doc(db,"couples",coupleId,"members",uid),{
    name,role:"member",createdAt:serverTimestamp()
  },{merge:true});
}
export function coupleIdFromUsers(uidA,uidB){
  return [uidA,uidB].sort().join("_");
}
