/**
 * Non-destructive local migration.
 * Existing localStorage is never cleared by this module.
 */
export function snapshotLocalState(storageKey="jovana_stefan_state"){
  try{
    const raw=localStorage.getItem(storageKey);
    return raw?JSON.parse(raw):null;
  }catch(_){ return null; }
}
export function migrationPayload(state,uid){
  return { state, migratedBy:uid, migratedAt:Date.now(), schemaVersion:1 };
}
