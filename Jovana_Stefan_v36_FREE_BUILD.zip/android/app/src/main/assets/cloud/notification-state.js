export function unreadCount(items,uid){
  return (items||[]).filter(x=>x.recipientUid===uid && !x.read).length;
}
export function markRead(items,id){
  return (items||[]).map(x=>x.id===id?{...x,read:true}:x);
}
