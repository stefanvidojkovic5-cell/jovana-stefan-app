export function makeAuditEvent({uid,action,entity,entityId,notifyOther=false}){
  return {
    uid,action,entity,entityId:String(entityId||""),
    notifyOther:!!notifyOther,createdAt:Date.now()
  };
}
