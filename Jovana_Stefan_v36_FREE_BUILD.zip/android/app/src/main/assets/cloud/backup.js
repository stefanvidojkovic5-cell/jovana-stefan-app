export function exportState(state){
  return JSON.stringify({
    app:"Jovana & Stefan",
    version:1,
    exportedAt:new Date().toISOString(),
    state
  },null,2);
}
export function importState(text){
  const obj=JSON.parse(text);
  if(!obj || obj.app!=="Jovana & Stefan" || !obj.state) throw new Error("Neispravan backup.");
  return obj.state;
}
