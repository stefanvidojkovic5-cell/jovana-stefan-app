# Production status

Implemented in this package:
- Android wrapper
- existing app preserved
- Firebase SDK dependencies
- Firestore/Storage security-rule skeleton
- shared couple data model
- offline-first sync module
- FCM notification contract
- migration plan

Still requires a real user-owned Firebase project:
- Firebase project credentials / google-services.json
- Authentication users for Jovana and Stefan
- exact couple membership documents
- deploying rules and notification function
- Android signing/build and installation

No passwords or private credentials are included in this package.
