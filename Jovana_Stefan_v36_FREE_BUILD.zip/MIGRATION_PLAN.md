# Local -> cloud migration

Existing localStorage data is retained. At first successful cloud login, the app
can upload the existing state as a migration snapshot. The production version
should then normalize it into the Firestore collections defined in firebase/DATA_MODEL.md.

No existing user data should be deleted during migration.
