# Release build

Firebase config is present in android/app/google-services.json.

Release still needs to be built in an Android/Gradle environment:
- assembleDebug for a test APK
- assembleRelease after configuring a signing key

The signing key should never be uploaded into the project or chat.
