v19 preserves the entire v18 app and adds a cloud-aware persistence bridge.
Local storage remains the fallback. When a real Firebase config is supplied,
saveShared() persists the shared state and the authentication bridge can sign
users in/register them. Further hardening needed before production: per-user
couple membership rules, migration of each collection into normalized
Firestore documents, FCM notification delivery, Storage upload rules, and
production signing/build pipeline.
