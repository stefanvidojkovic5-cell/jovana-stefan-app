v25: Firebase Android configuration connected.

The user-provided google-services.json was validated and copied into
android/app/google-services.json. Existing application features are preserved.

Still external/runtime dependent:
- enable/configure Firebase Authentication, Firestore, Storage, Messaging
- deploy Firestore/Storage rules and Cloud Function
- create Jovana and Stefan accounts
- build/sign/install the Android package

These steps require access to the actual Firebase project/build environment.
