# v35 — live Firebase Auth + Firestore sync

Code-side work completed:
- activated the supplied Firebase client configuration in the Android bundled app
- login/registration now initializes against the real Firebase project
- authenticated UID is checked against `couples/jovana-stefan/members/{uid}`
- shared state is stored in `couples/jovana-stefan`
- realtime listener updates both phones when the shared state document changes
- localStorage remains the offline cache
- Android session bridge receives the signed-in UID/email
- existing app features are preserved

User-side prerequisites already prepared:
- Firestore database exists
- Firestore rules were published
- Jovana member document exists
- Stefan member document exists
- both Firebase Auth users exist

Remaining runtime step:
- build/install this Android project and sign in on each phone with the two accounts.
