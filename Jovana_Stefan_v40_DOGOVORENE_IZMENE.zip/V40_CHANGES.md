# Jovana & Stefan v40 — dogovorene izmene

Ova verzija je pripremljena na osnovu poslednje realne verzije sa Firebase prijavom.

Urađeno:
- prvi ekran je samo Firebase prijava;
- posle prijave ulazi se u aplikaciju;
- Firebase sesija se pamti na telefonu i ostaje aktivna do Odjave;
- Odjava je u Podešavanja;
- dodatna zaštita od preklapanja sa status barom telefona;
- uklonjen je vidljivi cloud/status baner iz glavnog sadržaja;
- uklonjena je posebna kartica „Obaveštenja“ iz glavne navigacije, bez brisanja postojećeg sistema obaveštenja;
- dodata Podešavanja;
- tema: Prati telefon / Svetla / Tamna;
- izbor teme se čuva samo lokalno na tom telefonu i ne upisuje se u Firebase;
- promena lozinke uz proveru trenutne lozinke;
- postojeće sekcije i podaci nisu namerno uklanjani;
- fotografije/Supabase nisu menjani u ovoj verziji.

Build:
GitHub Actions treba da raspakuje ovaj ZIP i pokrene `gradle --no-daemon assembleDebug` iz `project/android`.
